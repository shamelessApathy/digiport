	var Calculator = function(data) {
		this.data = data
		this.sendData = function() {
			var data = this.data;
			console.log(data);	  
		    $.ajax({
            type: 'POST',
            url: '../phpcalc.php',
            data: data,
            success: function (response) {
				var result = response;
				var answer = document.getElementsByClassName('answer')[0];
				answer.innerHTML = result;
				console.log(result);
	  }})
		};
	}
document.addEventListener('DOMContentLoaded', function() {
var submit = document.getElementById('submit');
	submit.addEventListener('click', function() {
		var yourIncome = document.getElementsByTagName('input')[0].value;
		var spouseIncome = document.getElementsByTagName('input')[1].value;
		var marriageLength = document.getElementsByTagName('input')[2].value;
		var children = document.getElementsByTagName('input')[3]
		if (children.checked){
			var children = 1;
		}
		else { var children = 0;}
		var pass = {yourIncome:yourIncome, spouseIncome:spouseIncome, marriageLength:marriageLength, children:children};
		var calculator = new Calculator(pass);
		calculator.sendData();
	})


})
	
